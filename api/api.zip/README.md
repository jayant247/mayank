# Codeigniter REST API #

See the article http://net.tutsplus.com/tutorials/php/working-with-restful-services-in-codeigniter-2/ 

## Demo: 
https://demo.halimlardjane.com/ci-rest


## Screenshot:

![alt tag](https://github.com/halimus/codeigniter-rest-api/blob/master/_mpd/images/1.JPG)

![alt tag](https://github.com/halimus/codeigniter-rest-api/blob/master/_mpd/images/2.JPG)

![alt tag](https://github.com/halimus/codeigniter-rest-api/blob/master/_mpd/images/3.JPG)

![alt tag](https://github.com/halimus/codeigniter-rest-api/blob/master/_mpd/images/4.JPG)

![alt tag](https://github.com/halimus/codeigniter-rest-api/blob/master/_mpd/images/5.JPG)

![alt tag](https://github.com/halimus/codeigniter-rest-api/blob/master/_mpd/images/6.JPG)

